// SnipIT Local Configuration
// This file is gitignored. Do not remove it from .gitignore.
const OPENROUTER_API_KEY = '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';
